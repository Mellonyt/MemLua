// File: memcondets.h
// Meaning: Controllable Detours in memory
// Purpose(s):
//   - Create sophisticated, controlled detours and hooks in memory
//   - Allow synchronized, non-synchronized, or even timed hooks.
//   - Enable full call-stack dumping, function analysis and
//         exceptioned debugging.
//   - Accomplish all of these using just a few lines
// Usage:
//   (unavailable yet)
// 
// 
// ### C Headers ###
#pragma once
#include <Windows.h>

#define MEMDEBUG_MAX 128
#define MEMDEBUG_LARGE_OFFSET 0x10000000

enum
{
	MEMDEBUG_EAX,
	MEMDEBUG_ECX,
	MEMDEBUG_EDX,
	MEMDEBUG_EBX,
	MEMDEBUG_ESP,
	MEMDEBUG_EBP,
	MEMDEBUG_ESI,
	MEMDEBUG_EDI
};

// ### Collection of detouring/hooking API functions ###
namespace MemDetours
{
	struct MemDetour
	{
	private:
		DWORD old_protect;
		BYTE old_bytes[16];
	public:
		void* address;
		void* func;
		size_t size;

		~MemDetour()
		{
			address = nullptr;
			func = nullptr;
		};

		MemDetour()
		{
			address = nullptr;
			func = nullptr;
			size = NULL;
			old_protect = NULL;
			RtlZeroMemory(old_bytes, 16);
		};


		MemDetour(void* location, void* function, size_t nops)
		{
			address = location;
			func = function;
			size = 5 + nops;
			RtlZeroMemory(old_bytes, 16);
		};


		void Activate()
		{
			// Save original bytes
			memcpy(&old_bytes, address, size);

			// Set memory page to editable
			VirtualProtect(address, size, PAGE_EXECUTE_READWRITE, &old_protect);

			DWORD at = reinterpret_cast<DWORD>(address);

			// Jmp to our hook function
			*(BYTE*)(at++) = 0xE9;
			*(DWORD*)at = (reinterpret_cast<DWORD>(func) - at) + 6;
			at += sizeof(DWORD);

			// Add our NOP's
			for (int i = 5; i < size; i++) {
				*(BYTE*)(at++) = 0x90;
			}

			VirtualProtect(address, size, old_protect, &old_protect);
		}


		void Deactivate()
		{
			VirtualProtect(address, size, PAGE_EXECUTE_READWRITE, &old_protect);
			memcpy(address, &old_bytes, size);
			VirtualProtect(address, size, old_protect, &old_protect);
		}
	};

	MemDetour DetourFunction(void* location, size_t nops, void* func)
	{
		return MemDetour(location, func, nops);
	}


	void* GetFunc(const char* modulename, const char* functionname)
	{
		HMODULE hmodule = GetModuleHandleA(modulename);

		if (hmodule == nullptr) {
			SetLastError(ERROR_INVALID_HANDLE);
			return nullptr;
		}

		return GetProcAddress(hmodule, functionname);
	}

	// ### ABOUT ###
	// This can be used to either deaden/disable a function,
	// or cause it to return a constant value.
	// 
	// ### USAGE ###
	// DisableFunction(&FreeConsole, 0); // disabled!
	// 
	void DisableFunction(void* func, size_t stack_size, bool forcereturn = false, DWORD returnvalue = 0)
	{
		DWORD old_protect;
		VirtualProtect(func, 16, PAGE_EXECUTE_READWRITE, &old_protect);

		DWORD at = reinterpret_cast<DWORD>(func);

		if (forcereturn) {
			if (returnvalue == 0)
			{
				*(WORD*)(at) = 0xC033; // xor eax,eax
				at += sizeof(WORD);
			}
			else
			{
				*(BYTE*)(at++) = 0xC7; // mov eax, returnvalue
				*(BYTE*)(at++) = 0xC0;
				*(DWORD*)(at) = returnvalue;
				at += sizeof(DWORD);

			}
		}

		if (!stack_size)
		{
			*(BYTE*)(at++) = 0xC3; // retn
		}
		else
		{ 
			*(DWORD*)(at++) = 0xC2; // ret stack_size
			*(WORD*)(at) = stack_size;
			at += sizeof(WORD);
		}

		// Blotch out the rest
		while (at < reinterpret_cast<DWORD>(func) + 16) {
			*(BYTE*)(at++) = 0xCC;
		}

		VirtualProtect(func, 16, old_protect, &old_protect);
	}

	// ### ABOUT ###
	// This dumps the call stack of a function at the
	// specified point(`location`) when it's reached.
	// DumpCallStack will yield program execution until
	// the function being hooked is called.
	// The contents will be placed into `output`
	// 
	// ### USAGE ###
	// int callstack[MEMDEBUG_MAX];
	// DumpCallStack(&callstack, function_in_memory, 0);
	// . . .
	// . . . (this will delay until the function is called) . . .
	// . . .
	// printf("Listing functions that called %08X...\n\n", function_in_memory);
	// printf("Caller function #1: %08X\n", callstack[0]);
	// printf("Caller function #2: %08X\n", callstack[1]);
	// printf("Caller function #3: %08X\n", callstack[2]);
	// . . . 
	// . . .
	// 
	bool DumpCallStack(void* output, void* location, size_t nops, bool async = true)
	{
		BYTE* dataRead = (BYTE*)output;
		RtlZeroMemory(dataRead, MEMDEBUG_MAX);

		DWORD oldProtect;
		DWORD rel;
		DWORD init_hook_size = 5 + nops;
		DWORD hook_address = reinterpret_cast<DWORD>(location);
		DWORD hook_jmpback = hook_address + init_hook_size;

		// Store the original bytes
		BYTE* old_bytes = new BYTE[init_hook_size];
		memcpy(old_bytes, location, init_hook_size);

		// Create a new function
		DWORD hook_size = init_hook_size;
		DWORD detour_func = reinterpret_cast<DWORD>(VirtualAlloc(nullptr, 128, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));

		// Copy the bytes we're replacing with our hook
		// into the beginning of our new function
		for (size_t i = 0; i < hook_size; i++) {
			*(BYTE*)(detour_func + i) = *(BYTE*)(hook_address + i);
		}

		// When [location] is invoked, this instruction
		// will set dataRead[0] to 1, implying that execution
		// has reached the hook, and we can remove the hook
		// 
		*(BYTE*)(detour_func + hook_size++) = 0xC7; // mov [dataRead], 1
		*(BYTE*)(detour_func + hook_size++) = 0x05;
		*(DWORD*)(detour_func + hook_size) = (DWORD)dataRead + 0;
		hook_size += sizeof(DWORD);
		*(DWORD*)(detour_func + hook_size) = 1;
		hook_size += sizeof(DWORD);


		*(BYTE*)(detour_func + hook_size++) = 0x50; // push eax

		*(BYTE*)(detour_func + hook_size++) = 0x8B; // mov eax, [ebp+4]
		*(BYTE*)(detour_func + hook_size++) = 0x45;
		*(BYTE*)(detour_func + hook_size++) = 0x04;

		// Dump all possible offsets of EBP
		for (int i = 0; i < MEMDEBUG_MAX - 1; i++) {
			*(BYTE*)(detour_func + hook_size++) = 0x8B; // mov eax, [eax+4]
			*(BYTE*)(detour_func + hook_size++) = 0x40;
			*(BYTE*)(detour_func + hook_size++) = 0x04;

			*(BYTE*)(detour_func + hook_size++) = 0x89; // mov [dataRead + xx], eax
			*(BYTE*)(detour_func + hook_size++) = 0x05;
			*(DWORD*)(detour_func + hook_size) = (DWORD)dataRead + 4 + (i * 4);
			hook_size += sizeof(DWORD);
		}
		*(BYTE*)(detour_func + hook_size++) = 0x58; // pop eax

		/*
		// Dump all registers EAX-EDI
		for (int i = 0; i < 8; i++) {
			*(BYTE*)(detour_func + hook_size++) = 0x89;
			*(BYTE*)(detour_func + hook_size++) = 0x05 + (8 * i);
			*(int*)(detour_func + hook_size) = (int)dataRead + 4 * (i + 1);
			hook_size += 4;
		}*/

		// Place a JMP leading back to the original function,
		// continuing the flow of execution
		rel = hook_address - (DWORD)(detour_func + hook_size + 5 - init_hook_size);
		*(BYTE*)(detour_func + hook_size++) = 0xE9;
		*(DWORD*)(detour_func + hook_size) = rel;
		hook_size += sizeof(DWORD);

		// Set memory page to be editable
		VirtualProtect(location, init_hook_size, PAGE_EXECUTE_READWRITE, &oldProtect);

		// Write our hook now
		// Place the jmp to our debug function
		*(BYTE*)hook_address = 0xE9;
		*(DWORD*)(hook_address + 1) = ((DWORD)detour_func - hook_address) - 5;
		
		// Place NOP's
		for (size_t i = 5; i < init_hook_size; i++) {
			*(BYTE*)(hook_address + i) = 0x90;
		}

		VirtualProtect(location, init_hook_size, oldProtect, &oldProtect);

		if (async) {
			// Delay the current thread until the
			// function is invoked and the call stack dumped
			while (dataRead[0] == 0) Sleep(10);

			// Remove the hook
			VirtualProtect(location, init_hook_size, PAGE_EXECUTE_READWRITE, &oldProtect);
			memcpy(location, old_bytes, init_hook_size);
			VirtualProtect(location, init_hook_size, oldProtect, &oldProtect);
		}

		delete[] old_bytes;

		return true;
	}
	
	BOOL DumpStack(void* output, void* location, size_t nops, bool async = true)
	{
		int* dataRead = (int*)output;
		RtlZeroMemory(dataRead, MEMDEBUG_MAX);

		DWORD oldProtect;
		DWORD rel;
		DWORD init_hook_size = 5 + nops;
		DWORD hook_address = reinterpret_cast<DWORD>(location);
		DWORD hook_jmpback = hook_address + init_hook_size;

		// Store the original bytes
		BYTE* old_bytes = new BYTE[init_hook_size];
		memcpy(old_bytes, location, init_hook_size);

		// Create a new function
		DWORD hook_size = init_hook_size;
		DWORD detour_func = reinterpret_cast<DWORD>(VirtualAlloc(nullptr, 128, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));

		// Copy the bytes we're replacing with our hook
		// into the beginning of our new function
		for (size_t i = 0; i < hook_size; i++) {
			*(BYTE*)(detour_func + i) = *(BYTE*)(hook_address + i);
		}

		// When [location] is invoked, this instruction
		// will set dataRead[0] to 1, implying that execution
		// has reached the hook, and we can remove the hook
		// 
		*(BYTE*)(detour_func + hook_size++) = 0xC7; // mov [dataRead], 1
		*(BYTE*)(detour_func + hook_size++) = 0x05;
		*(DWORD*)(detour_func + hook_size) = (DWORD)dataRead + 0;
		hook_size += sizeof(DWORD);
		*(DWORD*)(detour_func + hook_size) = 1;
		hook_size += sizeof(DWORD);


		*(BYTE*)(detour_func + hook_size++) = 0x50; // push eax
		
		for (int i = 0, j = 0; i < MEMDEBUG_MAX - 1; i++, j += 4) {
			*(BYTE*)(detour_func + hook_size++) = 0x8B; // mov eax, [ebp+j]
			*(BYTE*)(detour_func + hook_size++) = 0x45;
			*(BYTE*)(detour_func + hook_size++) = 0x08 + j;

			*(BYTE*)(detour_func + hook_size++) = 0x89; // mov [dataRead + xx], eax
			*(BYTE*)(detour_func + hook_size++) = 0x05;
			*(DWORD*)(detour_func + hook_size) = (DWORD)dataRead + 4 + (i * 4);
			hook_size += sizeof(DWORD);
		}
		
		*(BYTE*)(detour_func + hook_size++) = 0x58; // pop eax

		// Place a JMP leading back to the original function,
		// continuing the flow of execution
		rel = hook_address - (DWORD)(detour_func + hook_size + 5 - init_hook_size);
		*(BYTE*)(detour_func + hook_size++) = 0xE9;
		*(DWORD*)(detour_func + hook_size) = rel;
		hook_size += sizeof(DWORD);

		// Set memory page to be editable
		VirtualProtect(location, init_hook_size, PAGE_EXECUTE_READWRITE, &oldProtect);

		// Write our hook now
		// Place the jmp to our debug function
		*(BYTE*)hook_address = 0xE9;
		*(DWORD*)(hook_address + 1) = ((DWORD)detour_func - hook_address) - 5;
		
		// Place NOP's
		for (size_t i = 5; i < init_hook_size; i++) {
			*(BYTE*)(hook_address + i) = 0x90;
		}

		VirtualProtect(location, init_hook_size, oldProtect, &oldProtect);

		if (async) {
			// Delay the current thread until the
			// function is invoked and the call stack dumped
			while (dataRead[0] == 0) Sleep(10);

			// Remove the hook
			VirtualProtect(location, init_hook_size, PAGE_EXECUTE_READWRITE, &oldProtect);
			memcpy(location, old_bytes, init_hook_size);
			VirtualProtect(location, init_hook_size, oldProtect, &oldProtect);
		}

		delete[] old_bytes;

		return true;
	}


	// ### ABOUT ###
	// If you want to read, for example, [EBX + 4C],
	// at a specific location in a function, we would do:
	// 
	// ### USAGE ###
	// int data = DebugFunction(function_in_memory, 0, MEMDEBUG_EBX, 0x4C);
	// printf("[ebx+4C] = %08X\n", data);
	// 
	DWORD DebugFunction(void* location, size_t nops, BYTE debug_register, DWORD debug_register_offset)
	{
		DWORD oldProtect, rel, value = 0, debug_hit = 0;
		DWORD init_hook_size = 5 + nops;

		DWORD hook_address = reinterpret_cast<DWORD>(location);
		DWORD hook_jmpback = hook_address + init_hook_size;

		// Store the original bytes
		BYTE* old_bytes = new BYTE[init_hook_size];
		memcpy(old_bytes, location, init_hook_size);

		// Create a new function
		DWORD hook_size = init_hook_size;
		DWORD detour_func = reinterpret_cast<DWORD>(VirtualAlloc(nullptr, 128, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));
		
		// Copy the bytes we're replacing with our hook
		// into the beginning of our new function
		for (size_t i = 0; i < hook_size; i++) {
			*(BYTE*)(detour_func + i) = *(BYTE*)(hook_address + i);
		}

		// When [location] is invoked, this instruction
		// will set `debugged` to 1, implying that execution
		// has reached the hook, and we can remove the hook
		// 
		*(BYTE*)(detour_func + hook_size++) = 0xC7; // mov [debugged], 1
		*(BYTE*)(detour_func + hook_size++) = 0x05;
		*(DWORD*)(detour_func + hook_size) = reinterpret_cast<DWORD>(&debug_hit);
		hook_size += sizeof(DWORD);
		*(DWORD*)(detour_func + hook_size) = 1;
		hook_size += sizeof(DWORD);


		*(BYTE*)(detour_func + hook_size++) = 0x50; // push eax

		*(BYTE*)(detour_func + hook_size++) = 0x8B; // mov eax, [reg+offset]
		if (debug_register_offset & MEMDEBUG_LARGE_OFFSET) {
			*(BYTE*)(detour_func + hook_size++) = 0x80 + debug_register;
			*(DWORD*)(detour_func + hook_size) = debug_register_offset;
			hook_size += sizeof(DWORD);
		} else {
			*(BYTE*)(detour_func + hook_size++) = 0x40 + debug_register;
			*(BYTE*)(detour_func + hook_size++) = debug_register_offset;
		}

		*(BYTE*)(detour_func + hook_size++) = 0x89; // mov [value], eax
		*(BYTE*)(detour_func + hook_size++) = 0x05;
		*(DWORD*)(detour_func + hook_size) = reinterpret_cast<DWORD>(&value);
		hook_size += sizeof(DWORD);

		*(BYTE*)(detour_func + hook_size++) = 0x58; // pop eax


		// Place a JMP leading back to the original function,
		// continuing the flow of execution
		rel = hook_address - (DWORD)(detour_func + hook_size + 5 - init_hook_size);
		*(BYTE*)(detour_func + hook_size++) = 0xE9;
		*(DWORD*)(detour_func + hook_size) = rel;

		// Set memory page to be editable
		VirtualProtect(location, init_hook_size, PAGE_EXECUTE_READWRITE, &oldProtect);

		// Write our hook now
		// Place the jmp to our debug function
		*(BYTE*)hook_address = 0xE9;
		*(DWORD*)(hook_address + 1) = ((DWORD)detour_func - hook_address) - 5;
		
		// Place NOP's
		for (size_t i = 5; i < init_hook_size; i++) {
			*(BYTE*)(hook_address + i) = 0x90;
		}

		VirtualProtect(location, init_hook_size, oldProtect, &oldProtect);

		// Delay the current thread until the
		// hook succeeds and a value was obtained
		while (!debug_hit) Sleep(10);

		// Remove the hook
		VirtualProtect(location, init_hook_size, PAGE_EXECUTE_READWRITE, &oldProtect);
		memcpy(location, old_bytes, init_hook_size);
		VirtualProtect(location, init_hook_size, oldProtect, &oldProtect);

		delete[] old_bytes;

		return value;
	}
}







