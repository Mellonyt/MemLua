#pragma once
#include <Windows.h>
#include <string>
#include <vector>
#include "conventions.h"
#include "memscan.h"
#include "httpreader.h"
#include <fstream>

extern "C" {
	#include "Lua/lua.h"
	#include "Lua/lualib.h"
	#include "Lua/lauxlib.h"
	#include "Lua/ldo.h"
	#include "Lua/lapi.h"
}

#define lua_pushfunction(L, x, name) \
						lua_pushcfunction(L, x); \
						lua_setglobal(L, name)

#define isPrologue(x)	((x % 16 == 0) && \
						((*(BYTE*)x == 0x55 && *(WORD*)(x + 1) == 0xEC8B) || \
						(*(BYTE*)x == 0x53 && *(WORD*)(x + 1) == 0xDC8B) || \
						(*(BYTE*)x == 0x56 && *(WORD*)(x + 1) == 0xF48B)))

#define isEpilogue(x)	(*(WORD*)(x - 1) == 0xC35D || \
						(*(WORD*)(x - 1) == 0xC25D && *(WORD*)(x + 1) >= 0 && *(WORD*)(x + 1) % 4 == 0))

#define isValidCode(x)	!(*(ULONGLONG*)x == NULL && *(ULONGLONG*)(x + 8) == NULL)

#define getRel(x)		((x+*(DWORD*)(x+1)+5) % 16 == 0 ? (x+*(DWORD*)(x+1)+5) : NULL)

#define addInteger(L, name, x)\
	lua_pushinteger(L, x); \
	lua_setfield(L, -2, name)

#define addGlobalInteger(L, name, x)\
	lua_pushinteger(L, x); \
	lua_setglobal(L, name)

//
// For easy assembler code
//
#define memPushLargeArg(x, value) \
	*(BYTE*)(x++) = 0x68; \
	*(DWORD*)x = value; \
	x += sizeof(DWORD);

#define memPushSmallArg(x, value) \
	*(BYTE*)(x++) = 0x6A; \
	*(BYTE*)(x++) = value;

// Places a call instruction at x, to func, plus stack clean (if specified)
#define memPlaceCall(x, func, cleanup) \
	*(BYTE*)x = 0xE8; \
	*(DWORD*)(x + 1) = (reinterpret_cast<DWORD>(func) - x) - 5; \
	x += 5; \
	if (cleanup > 0) { \
		*(BYTE*)(x++) = 0x83; \
		*(BYTE*)(x++) = 0xC4; \
		*(BYTE*)(x++) = cleanup; \
	} \


BYTE toByte(const char* str) {
	// convert 2 chars to byte
	int id = 0, n = 0, byte = 0;
convert:
	if (str[id] > 0x60) n = str[id] - 0x57; // n = A-F (10-16)
	else if (str[id] > 0x40) n = str[id] - 0x37; // n = a-f (10-16)
	else if (str[id] >= 0x30) n = str[id] - 0x30; // number chars
	if (id != 0) byte += n; else {
		id++, byte += (n * 16);
		goto convert;
	}
	return byte;
}

void placeHook(DWORD address, size_t hookSize, DWORD func) {
	DWORD oldProtect;
	VirtualProtect(reinterpret_cast<void*>(address), hookSize, PAGE_EXECUTE_READWRITE, &oldProtect);

	*(BYTE*)address = 0xE9;
	*(DWORD*)(address + 1) = ((DWORD)func - address) - 5;

	// Place NOP's
	for (size_t i = 5; i < hookSize; i++) {
		*(BYTE*)(address + i) = 0x90;
	}

	VirtualProtect(reinterpret_cast<void*>(address), hookSize, oldProtect, &oldProtect);
}


namespace MemLua {
	lua_State* L = nullptr;
	int lastCodeCave = NULL;
	int _BASE = NULL;
	int _BASESIZE = NULL;
	int _VMP0 = NULL;
	int _VMP1 = NULL;
	HANDLE breakpoint_thread = nullptr;
	HANDLE veh_handle = nullptr;
	
	class yield {
	public:
		lua_State* thread;
		DWORD ms_start;
		long ms_delay;
	};

	class excBreakpoint {
	public:
		lua_State* lua_thread;

		// this breakpoint can find out whatever's accessing
		// multiple addresses; a full section if needed
		int Start;
		int End;
		char functionName[128];
		DWORD oldProtect;
		bool kill;

		excBreakpoint() {
			functionName[0] = '\0';
			kill = false;
		}

		~excBreakpoint() {}
	};

	std::vector<excBreakpoint>breakpoints; // Page Exception method
	std::vector<yield>yields;

	DWORD __stdcall YieldThread(LPVOID arg) {
		while (true) {
			for (int i = 0; i < yields.size(); i++){
				yield d = yields[i];
				if (GetTickCount() - d.ms_start > d.ms_delay) {
					lua_resume(d.thread, 0);
					yields.erase(yields.begin() + i, yields.end());
				}
			}
			Sleep(50);
		}

		return 0;
	}

	namespace Functions {
		static int lua_malloc(lua_State* L) {
			size_t size = lua_tointeger(L, 1);
			void* x = malloc(size);
			lua_pushinteger(L, reinterpret_cast<lua_Integer>(x));
			return 1;
		}

		static int lua_free(lua_State* L) {
			void* data = reinterpret_cast<void*>(lua_tointeger(L, 1));
			free(data);
			return 0;
		}

		static int lua_system(lua_State* L) {
			const char* cmd = lua_tostring(L, 1);
			system(cmd);
			return 0;
		}

		static int wait(lua_State* L) {
			long time = 10;
			if (lua_type(L, 1) > LUA_TNIL) {
				time = static_cast<long>(lua_tonumber(L, 1) * 1000.0);
			}

			Sleep(time);
			/*yield temp;
			temp.ms_start = GetTickCount();
			temp.ms_delay = time;
			temp.thread = L;
			yields.push_back(temp);
			*/
			lua_pushboolean(L, TRUE);
			return 1;// lua_yield(L, 1);
		}

		static int spawnThread(lua_State* L) {
			lua_getglobal(L, "coroutine");
			lua_getfield(L, -1, "create");
			lua_pushvalue(L, -3);
			lua_pcall(L, 1, 1, 0);

			lua_getglobal(L, "coroutine");
			lua_getfield(L, -1, "resume");
			lua_pushvalue(L, -3);
			lua_pcall(L, 1, 0, 0);
			return 0;
		}

		static int scanMemory(lua_State* L) {
			std::vector<int> results = {};

			const char* aob = lua_tostring(L, 1);
			if (lua_type(L, 2) == LUA_TBOOLEAN) {
				if (lua_type(L, 3) != LUA_TNUMBER) {
					results = MemScanner::scan(aob, lua_toboolean(L, 2));
				} else {
					results = MemScanner::scan(aob, lua_toboolean(L, 2), 1, lua_tointeger(L, 3));
				}
			} else {
				if (lua_type(L, 2) == LUA_TNUMBER) {
					results = MemScanner::scan(aob, false, 1, lua_tointeger(L, 2));
				} else {
					results = MemScanner::scan(aob);
				}
			}

			lua_newtable(L);
			for (int i = 0; i < results.size(); i++) {
				lua_pushinteger(L, results[i]);
				lua_rawseti(L, -2, i + 1);
			}

			return 1;
		}

		static int disassemble(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			disassembler::inst i = disassembler::read(address);
			
			lua_newtable(L); // instruction table
			addInteger(L, "len", i.len);
			addInteger(L, "flags", i.flags);
			addInteger(L, "pref", i.pref);
			addInteger(L, "address", i.address);
			addInteger(L, "rel8", i.rel8);
			addInteger(L, "rel16", i.rel16);
			addInteger(L, "rel32", i.rel32);
			lua_pushstring(L, i.opcode);
			lua_setfield(L, -2, "opcode");
			lua_pushstring(L, i.data);
			lua_setfield(L, -2, "data");

			lua_newtable(L); // src
			addInteger(L, "r8", i.src.r8);
			addInteger(L, "r16", i.src.r16);
			addInteger(L, "r32", i.src.r32);
			addInteger(L, "imm8", i.src.imm8);
			addInteger(L, "imm16", i.src.imm16);
			addInteger(L, "imm32", i.src.imm32);
			addInteger(L, "disp8", i.src.disp8);
			addInteger(L, "disp16", i.src.disp16);
			addInteger(L, "disp32", i.src.disp32);
			lua_setfield(L, -2, "src");

			lua_newtable(L); // dest
			addInteger(L, "r8", i.dest.r8);
			addInteger(L, "r16", i.dest.r16);
			addInteger(L, "r32", i.dest.r32);
			addInteger(L, "imm8", i.dest.imm8);
			addInteger(L, "imm16", i.dest.imm16);
			addInteger(L, "imm32", i.dest.imm32);
			addInteger(L, "disp8", i.dest.disp8);
			addInteger(L, "disp16", i.dest.disp16);
			addInteger(L, "disp32", i.dest.disp32);
			lua_setfield(L, -2, "dest");

			return 1;
		}

		static int messagebox(lua_State* L) {
			const char* msg = lua_tostring(L, 1);
			MessageBoxA(NULL, msg, "", MB_OK);
			return 0;
		}

		static int lua_readRawHttp(lua_State* L) {
			const char* strUrl = lua_tostring(L, 1);

			size_t len;
			const char* data = readRawHttp(strUrl, &len);
			lua_pushlstring(L, data, len);

			return 1;
		}

		static int readString(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			int i = 0;

			if (address < _BASE) {
				lua_pushlstring(L, "", 0);
				return 1;
			}

			if (lua_type(L, 2) > LUA_TNIL) {
				i = lua_tointeger(L, 2);

				char* str = new char[i];
				str[0] = '\0';
				memcpy(str, reinterpret_cast<void*>(address), i);

				lua_pushlstring(L, str, i);
				delete[] str;
			}
			else {
				char str[1024];

				while (i < 1024) {
					BYTE x = *(BYTE*)(address++);

					if (x >= 0x20 && x <= 0x7E) {
						str[i++] = static_cast<char>(x);
					} else {
						break;
					}
				}

				lua_pushlstring(L, str, i);
			}
			
			return 1;
		}

		static int readByte(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			if (address < _BASE) {
				lua_pushinteger(L, 0);
				return 1;
			}
			lua_pushinteger(L, static_cast<int>(*(BYTE*)address));
			return 1;
		}

		static int readBytes(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			DWORD len = lua_tointeger(L, 2);
			BOOL string = false;
			if (lua_type(L, 3) == LUA_TBOOLEAN) {
				string = lua_toboolean(L, 3);
			}
			
			if (!string) {
				lua_newtable(L);
				for (int i = 0; i < len; i++) {
					BYTE b = *(BYTE*)(address + i);
					lua_pushinteger(L, b);
					lua_rawseti(L, -2, i + 1);
				}
			}
			else {
				std::string str = "";
				for (int i = 0; i < len; i++) {
					BYTE b = *(BYTE*)(address + i);
					char c[4];
					sprintf_s(c, "%02X", b);
					str += c;
					str += " ";
				}

				lua_pushlstring(L, str.c_str(), str.length());
			}


			return 1;
		}

		static int readWord(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			if (address < _BASE) {
				lua_pushnumber(L, 0);
				return 1;
			}
			lua_pushnumber(L, static_cast<ULONGLONG>(*(WORD*)address));
			return 1;
		}

		static int readDword(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			if (address < _BASE) {
				lua_pushnumber(L, 0);
				return 1;
			}
			lua_pushnumber(L, static_cast<ULONGLONG>(*(DWORD*)address));
			return 1;
		}

		static int readFloat(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			if (address < _BASE) {
				lua_pushnumber(L, 0);
				return 1;
			}
			lua_pushnumber(L, static_cast<ULONGLONG>(*(float*)address));
			return 1;
		}

		static int readQword(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			if (address < _BASE) {
				lua_pushnumber(L, 0);
				return 1;
			}
			ULONGLONG value = *(ULONGLONG*)address;
			lua_pushnumber(L, static_cast<double>(value));
			return 1;
		}

		static int writeString(lua_State* L) {
			void* address = reinterpret_cast<void*>(lua_tointeger(L, 1));
			size_t len = 0;
			const char* str = lua_tolstring(L, 2, &len);

			DWORD oldProtect;
			VirtualProtect(address, 1, PAGE_EXECUTE_READWRITE, &oldProtect);
			memcpy(address, str, len);
			VirtualProtect(address, 1, oldProtect, &oldProtect);
			return 0;
		}

		static int writeByte(lua_State* L) {
			DWORD oldProtect, address = lua_tointeger(L, 1);
			VirtualProtect(reinterpret_cast<void*>(address), 1, PAGE_EXECUTE_READWRITE, &oldProtect);
			*(BYTE*)(address) = static_cast<BYTE>(lua_tointeger(L, 2));
			VirtualProtect(reinterpret_cast<void*>(address), 1, oldProtect, &oldProtect);
			return 0;
		}

		static int writeBytes(lua_State* L) {
			void* address = reinterpret_cast<void*>(lua_tointeger(L, -2));
			DWORD oldProtect, len = lua_objlen(L, -1);

			BYTE* bytes = new BYTE[len];
			for (int i = 0; i < len; i++) {
				lua_rawgeti(L, -1, i + 1);
				bytes[i] = lua_tointeger(L, -1);
				lua_pop(L, 1);
			}

			VirtualProtect(address, 1, PAGE_EXECUTE_READWRITE, &oldProtect);
			memcpy(address, bytes, len);
			VirtualProtect(address, 1, oldProtect, &oldProtect);
			
			delete[] bytes;
			return 0;
		}

		static int writeWord(lua_State* L) {
			DWORD oldProtect, address = lua_tointeger(L, 1);
			VirtualProtect(reinterpret_cast<void*>(address), 1, PAGE_EXECUTE_READWRITE, &oldProtect);

			WORD value = static_cast<WORD>(lua_tointeger(L, 2));
			*(WORD*)(address) = value;

			VirtualProtect(reinterpret_cast<void*>(address), 1, oldProtect, &oldProtect);
			return 0;
		}

		static int writeDword(lua_State* L) {
			DWORD oldProtect, address = lua_tointeger(L, 1);
			VirtualProtect(reinterpret_cast<void*>(address), 1, PAGE_EXECUTE_READWRITE, &oldProtect);

			DWORD32 value = static_cast<DWORD32>(lua_tointeger(L, 2));
			*(DWORD32*)(address) = value;

			VirtualProtect(reinterpret_cast<void*>(address), 1, oldProtect, &oldProtect);
			return 0;
		}

		static int writeFloat(lua_State* L) {
			DWORD oldProtect, address = lua_tointeger(L, 1);
			VirtualProtect(reinterpret_cast<void*>(address), 1, PAGE_EXECUTE_READWRITE, &oldProtect);

			float value = static_cast<float>(lua_tonumber(L, 2));
			*(float*)(address) = value;

			VirtualProtect(reinterpret_cast<void*>(address), 1, oldProtect, &oldProtect);
			return 0;
		}

		static int writeQword(lua_State* L) {
			DWORD oldProtect, address = lua_tointeger(L, 1);
			VirtualProtect(reinterpret_cast<void*>(address), 1, PAGE_EXECUTE_READWRITE, &oldProtect);
			
			DWORD64 value = static_cast<DWORD64>(lua_tonumber(L, 2));
			*(DWORD64*)(address) = value;

			VirtualProtect(reinterpret_cast<void*>(address), 1, oldProtect, &oldProtect);
			return 0;
		}

		static int setMemoryPage(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			DWORD dwSize = lua_tointeger(L, 2);
			DWORD newProtect = lua_tointeger(L, 3);
			DWORD oldProtect;

			VirtualProtect(reinterpret_cast<void*>(address), dwSize, newProtect, &oldProtect);
			lua_pushinteger(L, oldProtect);

			return 1;
		}

		static int queryMemoryRegion(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);

			MEMORY_BASIC_INFORMATION mbi = { 0 };
			VirtualQuery(reinterpret_cast<void*>(address), &mbi, sizeof(MEMORY_BASIC_INFORMATION));

			lua_newtable(L);
			lua_pushinteger(L, reinterpret_cast<DWORD>(mbi.AllocationBase));
			lua_setfield(L, -2, "AllocationBase");
			lua_pushinteger(L, mbi.AllocationProtect);
			lua_setfield(L, -2, "AllocationProtect");
			lua_pushinteger(L, reinterpret_cast<DWORD>(mbi.BaseAddress));
			lua_setfield(L, -2, "BaseAddress");
			lua_pushinteger(L, mbi.Protect);
			lua_setfield(L, -2, "Protect");
			lua_pushinteger(L, mbi.RegionSize);
			lua_setfield(L, -2, "RegionSize");
			lua_pushinteger(L, mbi.State);
			lua_setfield(L, -2, "State");
			lua_pushinteger(L, mbi.Type);
			lua_setfield(L, -2, "Type");

			return 1;
		}

		static int allocPageMemory(lua_State* L) {
			size_t size = 0x3FF;
			if (lua_type(L, 1) > LUA_TNIL) {
				size = lua_tointeger(L, 1);
			}
			void* address = VirtualAlloc(nullptr, size, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
			lua_pushinteger(L, reinterpret_cast<lua_Integer>(address));
			return 1;
		}

		static int freePageMemory(lua_State* L) {
			void* address = reinterpret_cast<void*>(lua_tointeger(L, 1));
			VirtualFree(address, 0, MEM_RELEASE);
			return 0;
		}

		static int hex_to_str(lua_State* L) {
			DWORD value = lua_tointeger(L, 1);
			size_t bits = 8;
			
			if (lua_type(L, 2) > LUA_TNIL)
				bits = lua_tointeger(L, 2);

			char str[16];
			sprintf_s(str, "%08X", value << (32 - (bits * 4)));
			lua_pushlstring(L, str, bits);

			return 1;
		}

		static int str_to_byte(lua_State* L) {
			const char* str = lua_tostring(L, 1);
			lua_pushinteger(L, toByte(str));
			return 1;
		}

		static int str_to_addr(lua_State* L) {
			std::string str = lua_tostring(L, 1);
			if (str.substr(0, 2) == "0x") {
				str.erase(0, 2);
			}

			BYTE* bytes = new BYTE[4];
			bytes[3] = toByte(str.substr(0, 2).c_str());
			bytes[2] = toByte(str.substr(2, 2).c_str());
			bytes[1] = toByte(str.substr(4, 2).c_str());
			bytes[0] = toByte(str.substr(6, 2).c_str());

			lua_pushinteger(L, *(int*)(int)bytes);
			return 1;
		}

		static int getExport(lua_State* L) {
			const char* moduleName = lua_tostring(L, -2);
			const char* functionName = lua_tostring(L, -1);

			HMODULE mod = GetModuleHandleA(moduleName);
			if (mod == nullptr) {
				lua_pushnil(L);
			} else {
				DWORD address = reinterpret_cast<DWORD>(GetProcAddress(mod, functionName));
				if (address == NULL) {
					lua_pushnil(L);
				} else {
					lua_pushinteger(L, address);
				}
			}

			return 1;
		}



		// local data = debugRegister(location, strRegister, (optional)offset);
		static int debugRegister(lua_State* L) {
			DWORD address = lua_tointeger(L, 1); // location
			DWORD hookSize = 0;
			DWORD reg = 0;
			DWORD offset = 0;
			if (lua_isnumber(L, 3)){
				offset = lua_tointeger(L, 3);
			}

			while (hookSize < 5) {
				hookSize += disassembler::read(address + hookSize).len;
			}

			// read the register string
			const char* strRegister = lua_tostring(L, 2);
			const char* strRegisters[] = { "eax", "ecx", "edx", "ebx", "esp", "ebp", "esi", "edi" };

			// identify the register/get the number value of it
			for (int i = 0; i < 8; i++) {
				if (strcmp(strRegister, strRegisters[i]) == 0) {
					reg = i;
					break;
				}
			}

			BYTE* oldBytes = new BYTE[hookSize];
			memcpy(oldBytes, reinterpret_cast<void*>(address), hookSize);

			void* detourFunc = VirtualAlloc(nullptr, 0x3FF, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
			DWORD at = reinterpret_cast<DWORD>(detourFunc);
			//printf("Detour function: %08X\n", detourFunc);

			// Copy original bytes to our hook
			for (int i = 0; i < hookSize; i++) {
				*(BYTE*)(at++) = *(BYTE*)(address + i);
			}

			BOOL dataRead = FALSE;
			DWORD value = NULL;

			// *(int*)dataRead = 1;
			// 
			*(BYTE*)(at++) = 0xC7; // mov [dataRead], 00000001
			*(BYTE*)(at++) = 0x05;
			*(PVOID*)(at) = &dataRead;
			at += sizeof(DWORD);
			*(DWORD*)(at) = 1;
			at += sizeof(DWORD);

			// read the offset of the register specified
			*(BYTE*)(at++) = 0x56; // push esi

			*(BYTE*)(at++) = 0x8B; // mov esi, [???+offset]
			*(BYTE*)(at++) = 0xB0 + reg;
			*(DWORD*)(at) = offset;
			at += sizeof(DWORD);

			*(BYTE*)(at++) = 0x89; // mov [value], esi
			*(BYTE*)(at++) = 0x35;
			*(PVOID*)(at) = &value;
			at += sizeof(DWORD);

			*(BYTE*)(at++) = 0x5E; // pop esi

			placeHook(at, 5, address + hookSize);
			placeHook(address, hookSize, reinterpret_cast<DWORD>(detourFunc));

			while (!dataRead) Sleep(10);

			// Restore original bytes
			DWORD oldProtect;
			VirtualProtect(reinterpret_cast<void*>(address), hookSize, PAGE_EXECUTE_READWRITE, &oldProtect);
			memcpy(reinterpret_cast<void*>(address), oldBytes, hookSize);
			VirtualProtect(reinterpret_cast<void*>(address), hookSize, oldProtect, &oldProtect);

			delete[] oldBytes;
			VirtualFree(detourFunc, 0, MEM_RELEASE);

			lua_pushinteger(L, value);
			return 1;
		}


		static int startTracer(lua_State* L) {
			lua_getglobal(L, "CURRENT_TRACER");
			lua_getfield(L, -1, "start_address");
			int address = lua_tointeger(L, -1);
			lua_pop(L, 1);
			lua_getfield(L, -1, "hook_size");
			int hookSize = lua_tointeger(L, -1);
			lua_pop(L, 1);
			lua_getfield(L, -1, "detour");
			int detourFunc = lua_tointeger(L, -1);
			lua_pop(L, 2);

			placeHook(address, hookSize, detourFunc);

			return 0;
		}

		static int stopTracer(lua_State* L) {
			lua_getglobal(L, "CURRENT_TRACER");
			lua_getfield(L, -1, "start_address");
			int address = lua_tointeger(L, -1);
			lua_pop(L, 1);
			lua_getfield(L, -1, "hook_size");
			int hookSize = lua_tointeger(L, -1);
			lua_pop(L, 1);
			lua_getfield(L, -1, "detour");
			int detourFunc = lua_tointeger(L, -1);
			lua_pop(L, 1);
			lua_getfield(L, -1, "old_bytes");

			int value = *(int*)(detourFunc + 0x200);

			// Restore original bytes
			DWORD oldProtect;
			VirtualProtect(reinterpret_cast<void*>(address), hookSize, PAGE_EXECUTE_READWRITE, &oldProtect);
			for (int i = 0; i < hookSize; i++) {
				lua_rawgeti(L, -1, i + 1);
				*(BYTE*)(address + i) = static_cast<BYTE>(lua_tointeger(L, -1));
				lua_pop(L, 1);
			}
			VirtualProtect(reinterpret_cast<void*>(address), hookSize, oldProtect, &oldProtect);
			VirtualFree((void*)detourFunc, 0, MEM_RELEASE);

			lua_pop(L, 1);
			lua_pushinteger(L, value);
			return 1;
		}

		static int setTracer(lua_State* L) {
			DWORD address = lua_tointeger(L, 1); // location
			DWORD hookSize = 0;
			DWORD reg = 0;
			DWORD offset = 0;
			if (lua_isnumber(L, 3)){
				offset = lua_tointeger(L, 3);
			}

			while (hookSize < 5) {
				hookSize += disassembler::read(address + hookSize).len;
			}

			// read the register string
			const char* strRegister = lua_tostring(L, 2);
			const char* strRegisters[] = { "eax", "ecx", "edx", "ebx", "esp", "ebp", "esi", "edi" };

			// identify the register/get the number value of it
			for (int i = 0; i < 8; i++) {
				if (strcmp(strRegister, strRegisters[i]) == 0) {
					reg = i;
					break;
				}
			}

			BYTE* oldBytes = new BYTE[hookSize];
			memcpy(oldBytes, reinterpret_cast<void*>(address), hookSize);

			void* detourFunc = VirtualAlloc(nullptr, 0x3FF, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
			DWORD at = reinterpret_cast<DWORD>(detourFunc);
			//printf("Detour function: %08X\n", detourFunc);
			DWORD value_offset = at + 0x200;

			// Copy original bytes to our hook
			for (int i = 0; i < hookSize; i++) {
				*(BYTE*)(at++) = *(BYTE*)(address + i);
			}

			*(BYTE*)(at++) = 0x81; // cmp [value_offset], 00000000
			*(BYTE*)(at++) = 0x3D;
			*(DWORD*)(at) = value_offset;
			at += sizeof(DWORD);
			*(DWORD*)(at) = 0;
			at += sizeof(DWORD);

			*(BYTE*)(at++) = 0x72; // go to +6 (skip setting value)
			*(BYTE*)(at++) = 0x6;

			*(BYTE*)(at++) = 0x89; // mov [value_offset],reg
			*(BYTE*)(at++) = 0x05 + (reg * 8);
			*(DWORD*)(at) = value_offset;
			at += sizeof(DWORD);

			// read the offset of the register specified
			/**(BYTE*)(at++) = 0x50 + reg; // push reg
			*(BYTE*)(at++) = 0x50; // push eax
			*(BYTE*)(at++) = 0x8B; // mov eax,[esp + 4];
			*(BYTE*)(at++) = 0x44;
			*(BYTE*)(at++) = 0x24;
			*(BYTE*)(at++) = 0x04;
			//*(BYTE*)(at++) = 0xA3; // mov [xxxxxxxx],eax
			*(BYTE*)(at++) = 0x89; // mov [xxxxxxxx],eax
			*(BYTE*)(at++) = 0x05;
			*(DWORD*)(at) = value_offset;
			at += sizeof(DWORD);
			*(BYTE*)(at++) = 0x58; // pop eax
			*(BYTE*)(at++) = 0x58 + reg; // pop reg*/

			placeHook(at, 5, address + hookSize);

			lua_newtable(L);

			lua_newtable(L);
			for (int i = 0; i < hookSize; i++) {
				lua_pushinteger(L, oldBytes[i]);
				lua_rawseti(L, -2, i + 1);
			}
			delete[] oldBytes;
			lua_setfield(L, -2, "old_bytes");

			lua_pushinteger(L, address);
			lua_setfield(L, -2, "start_address");
			lua_pushinteger(L, hookSize);
			lua_setfield(L, -2, "hook_size");
			lua_pushinteger(L, (int)detourFunc);
			lua_setfield(L, -2, "detour");

			lua_pushcfunction(L, startTracer);
			lua_setfield(L, -2, "start");
			lua_pushcfunction(L, stopTracer);
			lua_setfield(L, -2, "stop");

			lua_pushvalue(L, -1);
			lua_setglobal(L, "CURRENT_TRACER");
			return 1;
		}



		// We'll use this instead of createDetour
		// this will load it onto its own thread
		// entirely
		static int createSafeDetour(lua_State* L) {
			DWORD address = lua_tointeger(L, -2);

			char funcGlobalName[32];
			sprintf(funcGlobalName, "DETOUR_FUNC_%08X", address);
			lua_pushvalue(L, -1);
			lua_setglobal(L, funcGlobalName);

			char locGlobalName[32];
			sprintf(locGlobalName, "DETOUR_LOC_%08X", address);
			lua_pushvalue(L, -2);
			lua_setglobal(L, locGlobalName);

			std::string script = "spawnThread(function()\n";
			script += "createDetour_UNSAFE(\"";
			script += locGlobalName;
			script += "\", \"";
			script += funcGlobalName;
			script += "\")\n";
			script += "end)\n";

			luaL_loadbuffer(L, script.c_str(), script.length(), "DETOUR_PRELOAD");
			lua_pcall(L, 0, 0, 0);

			return 0;
		}

		// createDetour(location, function(data) end)
		//
		// by using createDetour at a specific address,
		// it will write a jmp there which leads to our
		// auto-generated assembly code.
		// Our assembly code grabs a couple registers/whatever
		// we can grab from the stack, and stores it in temporary
		// globals.
		// We also plant lua calls in the assembly code to run
		// the lua function you pass in a coroutine,
		// where all of the temporary globals are placed in a table
		// and usable as the first function arg
		// 
		static int createDetour(lua_State* L) {
			const char* locGlobalName = lua_tostring(L, 1);
			const char* funcGlobalName = lua_tostring(L, 2);

			lua_getglobal(L, locGlobalName);
			DWORD address = lua_tointeger(L, -1); // location
			lua_pop(L, 1);

			// Calculate the size (# of instructions to overwrite)
			DWORD hookSize = 0;
			while (hookSize < 5) {
				hookSize += disassembler::read(address + hookSize).len;
			}

			// Get the original bytes
			BYTE* oldBytes = new BYTE[hookSize];
			memcpy(oldBytes, reinterpret_cast<void*>(address), hookSize);

			// Create a new global for the address of our detour
			char* dataGlobalName = (char*)luaM_malloc(L, 32);
			sprintf(dataGlobalName, "DETOUR_DATA_%08X", address);

			DWORD detourHook = reinterpret_cast<DWORD>(VirtualAlloc(nullptr, 0x3FF, MEM_COMMIT, PAGE_EXECUTE_READWRITE));
			DWORD at = detourHook;

			// Create a new global for the detour hook data
			lua_newtable(L);
			lua_newtable(L);
			for (int i = 0; i < hookSize; i++) {
				lua_pushinteger(L, oldBytes[i]);
				lua_rawseti(L, -2, i + 1);
			}
			delete[] oldBytes;
			lua_setfield(L, -2, "bytes");
			lua_pushinteger(L, detourHook + 232 + 0);
			lua_setfield(L, -2, "eax");
			lua_pushinteger(L, detourHook + 232 + 4);
			lua_setfield(L, -2, "ecx");
			lua_pushinteger(L, detourHook + 232 + 8);
			lua_setfield(L, -2, "edx");
			lua_pushinteger(L, detourHook + 232 + 12);
			lua_setfield(L, -2, "ebx");
			lua_pushinteger(L, detourHook + 232 + 16);
			lua_setfield(L, -2, "esp");
			lua_pushinteger(L, detourHook + 232 + 20);
			lua_setfield(L, -2, "ebp_deprecated");
			lua_pushinteger(L, detourHook + 232 + 64); // we can dump most of the ebp args here
			lua_setfield(L, -2, "ebp");
			lua_pushinteger(L, detourHook + 232 + 24);
			lua_setfield(L, -2, "esi");
			lua_pushinteger(L, detourHook + 232 + 28);
			lua_setfield(L, -2, "edi");
			lua_setglobal(L, dataGlobalName);

			// Copy original bytes to our hook
			for (int i = 0; i < hookSize; i++) {
				*(BYTE*)(at++) = *(BYTE*)(address + i);
			}

			*(BYTE*)(at++) = 0x60; // pushad
			
			/**(BYTE*)(at++) = 0x8A; // mov al, [currentlyRunning]
			*(BYTE*)(at++) = 0x05;
			*(DWORD*)(at) = detourHook + 128;
			at += sizeof(DWORD);
			*(BYTE*)(at++) = 0x84; // test al,al
			*(BYTE*)(at++) = 0xC0;
			*(BYTE*)(at++) = 0x74; // jnz +5
			*(BYTE*)(at++) = 5;
			placeHook(at, 5, address + hookSize);	// jmp back; don't spawn another coroutine
			at += 5;								// until the current one is done

			*(BYTE*)(at++) = 0xFF; // inc [currentlyRunning]
			*(BYTE*)(at++) = 0x05;
			*(DWORD*)(at) = detourHook + 128;
			at += sizeof(DWORD);*/

			*(BYTE*)(at++) = 0x89; // mov [eaxLocation],eax
			*(BYTE*)(at++) = 0x05;
			*(DWORD*)(at) = (detourHook + 232 + 0);
			at += sizeof(DWORD);
			*(BYTE*)(at++) = 0x50; // push eax

			*(BYTE*)(at++) = 0x8B; // mov eax,ecx
			*(BYTE*)(at++) = 0xC1;
			*(BYTE*)(at++) = 0x89; // mov [ecxLocation],eax
			*(BYTE*)(at++) = 0x05;
			*(DWORD*)(at) = (detourHook + 232 + 4);
			at += sizeof(DWORD);

			*(BYTE*)(at++) = 0x8B; // mov eax,edx
			*(BYTE*)(at++) = 0xC2;
			*(BYTE*)(at++) = 0x89; // mov [edxLocation],eax
			*(BYTE*)(at++) = 0x05;
			*(DWORD*)(at) = (detourHook + 232 + 8);
			at += sizeof(DWORD);

			*(BYTE*)(at++) = 0x8B; // mov eax,ebx
			*(BYTE*)(at++) = 0xC3;
			*(BYTE*)(at++) = 0x89; // mov [ebxLocation],eax
			*(BYTE*)(at++) = 0x05;
			*(DWORD*)(at) = (detourHook + 232 + 12);
			at += sizeof(DWORD);

			*(BYTE*)(at++) = 0x8B; // mov eax,esi
			*(BYTE*)(at++) = 0xC6;
			*(BYTE*)(at++) = 0x89; // mov [esiLocation],eax
			*(BYTE*)(at++) = 0x05;
			*(DWORD*)(at) = (detourHook + 232 + 24);
			at += sizeof(DWORD);

			*(BYTE*)(at++) = 0x8B; // mov eax,edi
			*(BYTE*)(at++) = 0xC7;
			*(BYTE*)(at++) = 0x89; // mov [ediLocation],eax
			*(BYTE*)(at++) = 0x05;
			*(DWORD*)(at) = (detourHook + 232 + 28);
			at += sizeof(DWORD);

			// Let's load 8 EBP args into the ebp location...
			// (sorry for the limitations my guy)
			for (int i = 2; i < 10; i++) {
				*(BYTE*)(at++) = 0x8B; // mov eax,[ebp+xx]
				*(BYTE*)(at++) = 0x45;
				*(BYTE*)(at++) = 0 + (i * 4);
				*(BYTE*)(at++) = 0x89; // mov [ebpLocation],eax
				*(BYTE*)(at++) = 0x05;
				*(DWORD*)(at) = (detourHook + 232 + 64) + (i * 4);
				at += sizeof(DWORD);
			}

			*(BYTE*)(at++) = 0x56; // push esi

			*(BYTE*)(at++) = 0xBE; // mov esi, L
			*(DWORD*)(at) = reinterpret_cast<DWORD>(L);
			at += sizeof(DWORD);

			char strDetourHook[32];
			sprintf_s(strDetourHook, "0x%08X", detourHook);
			char strAddress[32];
			sprintf_s(strAddress, "0x%08X", address);

			std::string script = "";// "spawnThread(function()\n";

			// write the cleanup function here
			script += "function endDetour()\n writeBytes(";
			script += strAddress;
			script += ", ";
			script += dataGlobalName;
			script += ".bytes);\n";
			script += "freePageMemory(";
			script += strDetourHook;
			script += ")\n";
			script += "end\n";

			// this will invoke the lua function with
			// table data (containing most of the temporary
			// globals we made)
			script += funcGlobalName;
			script += "(";
			script += dataGlobalName;
			script += ")\n";

			//script += "end)\n";

			const char* bufferName = "DETOUR_PRELOAD";

			luaL_loadbuffer(L, script.c_str(), script.length(), bufferName);
			lua_setglobal(L, bufferName);

			memPushLargeArg(at, (DWORD)bufferName);	// push bufferName
			memPushLargeArg(at, LUA_GLOBALSINDEX);	// push GLOBALSINDEX
			*(BYTE*)(at++) = 0x56;					// push L
			memPlaceCall(at, lua_getfield, 0xC);	// lua_getfield(L, GLOBALSINDEX, bufferName)

			memPushSmallArg(at, 0);					// push 0
			memPushSmallArg(at, 0);					// push 0
			memPushSmallArg(at, 0);					// push 0
			*(BYTE*)(at++) = 0x56;					// push L (esi)
			memPlaceCall(at, lua_pcall, 0x10);		// lua_pcall(L, 0, 0, 0)

			*(BYTE*)(at++) = 0x5E;					// pop esi

			/**(BYTE*)(at++) = 0xC7; // mov eax, 0
			*(BYTE*)(at++) = 0xC0;
			*(DWORD*)(at) = 0;
			at += sizeof(DWORD);
			*(BYTE*)(at++) = 0xA3; // mov [currentlyRunning],eax
			*(DWORD*)(at) = detourHook + 128;
			at += sizeof(DWORD);*/

			*(BYTE*)(at++) = 0x58;					// pop eax
			*(BYTE*)(at++) = 0x61;					// popad

			placeHook(at, 5, address + hookSize);
			placeHook(address, hookSize, detourHook);

			return 0;
		}

		// Converts any function into a cdecl (default convention)
		// by creating a new routine that mimics a cdecl
		// 
		static int lua_createRoutine(lua_State* L) {
			DWORD func = lua_tointeger(L, 1);
			DWORD n_Args = lua_tointeger(L, 2);
			int new_func = createRoutine(func, n_Args);
			lua_pushinteger(L, new_func);
			return 1;
		}
		 
		static int startRoutine(lua_State* L) {
			DWORD func = lua_tointeger(L, 1);
			LPVOID param = 0;
			if (lua_type(L, 2) > LUA_TNIL) {
				param = reinterpret_cast<void*>(lua_tointeger(L, 2));
			}
			HANDLE thread = CreateThread(0, 0, reinterpret_cast<LPTHREAD_START_ROUTINE>(func), param, 0, 0);
			lua_pushinteger(L, reinterpret_cast<lua_Integer>(thread));
			return 1;
		}

		static int cloneFunction(lua_State* L) {
			DWORD start = lua_tointeger(L, 1);
			DWORD fSize, end = start + 16;

			while (!(isPrologue(end) && isValidCode(end))) {
				end += 16;
			}

			fSize = end - start;

			DWORD newFunction = reinterpret_cast<DWORD>(VirtualAlloc(nullptr, fSize, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));
			DWORD at = newFunction;
			
			for (int i = 0; i < fSize; i++){
				if (*(BYTE*)start == 0xE8) {
					DWORD oldrel = *(DWORD*)(start + 1);
					DWORD relfunc = (start + oldrel) + 5;

					if (relfunc % 0x10 == 0) {
						DWORD newrel = relfunc - (at + 5);

						*(BYTE*)(at++) = *(BYTE*)(start++);
						*(DWORD*)(at) = newrel;
						at += sizeof(DWORD);
						start += sizeof(DWORD);
					}
				} else {
					*(BYTE*)(at++) = *(BYTE*)(start++);
				}
			}

			lua_pushinteger(L, newFunction);
			lua_pushinteger(L, fSize);
			return 2;
		}

		static int lua_getPrologue(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			
			if    (!isPrologue(address) and isValidCode(address)) address -= (address % 16);
			while (!isPrologue(address)) address -= 16;

			lua_pushinteger(L, address);
			return 1;
		}

		static int isFuncPrologue(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			lua_pushboolean(L, isPrologue(address));
			return 1;
		}

		static int isFuncEpilogue(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			lua_pushboolean(L, isEpilogue(address));
			return 1;
		}

		static int getFuncEpilogue(lua_State* L) {
			DWORD address = lua_tointeger(L, 1) + 16;
			while (!(isPrologue(address) && isValidCode(address))) {
				address += 16;
			}
			while (!isEpilogue(address)) address--;

			lua_pushinteger(L, address);
			return 1;
		}

		static int getNextPrologue(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);

			if (isPrologue(address)) {
				address += 16;
			} else {
				address += (address % 16);
			}
			while (!(isPrologue(address) && isValidCode(address))) {
				address += 16;
			}

			lua_pushinteger(L, address);
			return 1;
		}

		static int getNextEpilogue(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			if (isEpilogue(address)) address += 3;
			while (!isEpilogue(address)) address++;
			lua_pushinteger(L, address);
			return 1;
		}

		static int getPrevEpilogue(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			if (isEpilogue(address)) address -= 3;
			while (!isEpilogue(address)) address--;
			lua_pushinteger(L, address);
			return 1;
		}

		static int getPrevRef(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			DWORD address_look_for = lua_tointeger(L, 2);
			BOOL returnPrologue = FALSE;

			if (lua_type(L, 3) == LUA_TBOOLEAN) {
				returnPrologue = lua_toboolean(L, 3);
			}

			while (address > _BASE && address < _VMP0)
			{
				if (*(BYTE*)address == 0xE8 || *(BYTE*)address == 0xE9){
					if (getRel(address) == address_look_for) {
						break;
					}
				}
				address--;
			}

			if (!returnPrologue) {
				lua_pushinteger(L, address);
			} else {
				if    (!isPrologue(address)) address -= (address % 16);
				while (!isPrologue(address)) address -= 16;

				lua_pushinteger(L, address);
			}
			return 1;
		}

		static int getNextRef(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			DWORD address_look_for = lua_tointeger(L, 2);
			BOOL returnPrologue = FALSE;

			if (lua_type(L, 3) == LUA_TBOOLEAN) {
				returnPrologue = lua_toboolean(L, 3);
			}

			while (address > _BASE && address < _VMP0)
			{
				if (*(BYTE*)address == 0xE8 || *(BYTE*)address == 0xE9){
					if (getRel(address) == address_look_for)
						break;

					address += 5;
					continue;
				}
				address++;
			}

			if (!returnPrologue) {
				lua_pushinteger(L, address);
			} else {
				if    (!isPrologue(address)) address -= (address % 16);
				while (!isPrologue(address)) address -= 16;

				lua_pushinteger(L, address);
			}
			return 1;
		}

		static int getPrevRefs(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			DWORD address_look_for = lua_tointeger(L, 2);
			BOOL returnPrologue = FALSE;

			if (lua_type(L, 3) == LUA_TBOOLEAN) {
				returnPrologue = lua_toboolean(L, 3);
			}

			std::vector<DWORD>xrefs = {};

			while (address > _BASE && address < _VMP0)
			{
				if (*(BYTE*)address == 0xE8 || *(BYTE*)address == 0xE9)
				{
					if (getRel(address) == address_look_for) {
						if (!returnPrologue) {
							xrefs.push_back(address);
						} else {
							DWORD start = address;

							if  (!isPrologue(address)) start -= (start % 16);
							while (!isPrologue(start)) start -= 16;

							xrefs.push_back(start);
						}
					}
				}
				address--;
			}

			int i = 1;
			lua_newtable(L);
			for (int xref : xrefs) {
				lua_pushinteger(L, xref);
				lua_rawseti(L, -2, i++);
			}

			return 1;
		}

		static int getNextRefs(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			DWORD address_look_for = lua_tointeger(L, 2);
			BOOL returnPrologue = false;

			if (lua_type(L, 3) == LUA_TBOOLEAN) {
				returnPrologue = lua_toboolean(L, 3);
			}

			std::vector<DWORD>xrefs = {};

			while (address > _BASE && address < _VMP0)
			{
				if (*(BYTE*)address == 0xE8 || *(BYTE*)address == 0xE9)
				{
					if (getRel(address) == address_look_for) {
						if (!returnPrologue) {
							xrefs.push_back(address);
						} else {
							DWORD start = address - (address % 16);
							while (!isPrologue(start)) start -= 16;
							xrefs.push_back(start);
						}
					}
					address += 5;
					continue;
				}
				address++;
			}

			int i = 1;
			lua_newtable(L);
			for (int xref : xrefs) {
				lua_pushinteger(L, xref);
				lua_rawseti(L, -2, i++);
			}

			return 1;
		}

		static int getFunctionConvention(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			DWORD args = lua_tointeger(L, 2);
			lua_pushstring(L, getConvention(address, args));
			return 1;
		}

		static int getFunctionSize(lua_State* L) {
			DWORD start = lua_tointeger(L, 1);
			DWORD end = start;

			if (isPrologue(end)) {
				end += 16;
			}
			while (!(isPrologue(end) && isValidCode(end))) {
				end += 16;
			}

			lua_pushinteger(L, end - start);
			return 1;
		}

		static int getFunctionRet(lua_State* L) {
			WORD ret = 0;
			DWORD epilogue = lua_tointeger(L, 1) + 16;

			while (!(isPrologue(epilogue) && isValidCode(epilogue))) {
				epilogue += 16;
			}
			while (!isEpilogue(epilogue)) epilogue--;

			if (*(BYTE*)epilogue == 0xC2) {
				ret = *(WORD*)(epilogue + 1);
			}

			lua_pushinteger(L, ret);
			return 1;
		}

		static int getPrevCall(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			BOOL loc = false;
			BOOL checkprologue = false;
			DWORD rel = 0;

			if (lua_type(L, 2) == LUA_TBOOLEAN) {
				loc = lua_toboolean(L, 2);
			}

			if (lua_type(L, 3) == LUA_TBOOLEAN) {
				checkprologue = lua_toboolean(L, 3);
			}

			// Skip current call/jmp if possible
			if (*(BYTE*)address == 0xE8 || *(BYTE*)address == 0xE9) {
				address--;
			}

			// Decrement until we reach the very next call instruction
			while (true) {
				if (*(BYTE*)address == 0xE8 || *(BYTE*)address == 0xE9) {
					rel = getRel(address);
					if (rel > _BASE && rel < _VMP0) {
						if (checkprologue){
							if (isPrologue(rel)) {
								break;
							}
						} else {
							break;
						}
					}
				}
				address--;
			}

			if (!loc) {
				lua_pushinteger(L, rel);
			} else {
				lua_pushinteger(L, address);
			}

			return 1;
		}

		static int getNextCall(lua_State* L) {
			DWORD address = lua_tointeger(L, 1);
			BOOL loc = false;
			BOOL checkprologue = false;
			DWORD rel = 0;

			if (lua_type(L, 2) == LUA_TBOOLEAN) {
				loc = lua_toboolean(L, 2);
			}

			if (lua_type(L, 3) == LUA_TBOOLEAN) {
				checkprologue = lua_toboolean(L, 3);
			}

			// Skip current call/jmp if possible
			if (*(BYTE*)address == 0xE8 || *(BYTE*)address == 0xE9) {
				address++;
			}

			// Increment until we reach the very next call instruction
			while (true) {
				if (*(BYTE*)address == 0xE8 || *(BYTE*)address == 0xE9) {
					rel = getRel(address);
					if (rel > _BASE && rel < _VMP0) {
						if (checkprologue){
							if (isPrologue(rel)) {
								break;
							}
						} else {
							break;
						}
					}
				}
				address++;
			}

			if (!loc) {
				lua_pushinteger(L, rel);
			} else {
				lua_pushinteger(L, address);
			}

			return 1;
		}

		static int getFunctionCalls(lua_State* L) {
			std::vector<DWORD> calls = {};

			DWORD start = lua_tointeger(L, 1);
			DWORD end = start + 16;

			while (!(isPrologue(end) && isValidCode(end))) {
				end += 16;
			}

			while (start < end) {
				if (*(BYTE*)start == 0xE8 || *(BYTE*)start == 0xE9){
					DWORD rel = getRel(start);
					if (rel > _BASE && rel < _VMP0) {
						//if (isPrologue(rel)) {
							calls.push_back(rel);
							start += 5;
							continue;
						//}
					}
				}
				start++;
			}

			lua_newtable(L);
			for (int i = 0; i < calls.size(); i++) {
				lua_pushinteger(L, calls[i]);
				lua_rawseti(L, -2, i + 1);
			}

			return 1;
		}

		static int getFunctionPointers(lua_State* L) {
			std::vector<DWORD> pointers = {};

			DWORD start = lua_tointeger(L, 1);
			DWORD end = start + 16;

			while (!(isPrologue(end) && isValidCode(end))) {
				end += 16;
			}

			while (start < end) {
				disassembler::inst i = disassembler::read(start);

				if (i.flags & Fl_src_disp32 && i.src.disp32 % 4 == 0) {
					pointers.push_back(i.src.disp32);
				} else if (i.flags & Fl_dest_disp32 && i.dest.disp32 % 4 == 0){
					pointers.push_back(i.dest.disp32);
				}

				start += i.len;
			}

			lua_newtable(L);
			for (int i = 0; i < pointers.size(); i++) {
				lua_pushinteger(L, pointers[i]);
				lua_rawseti(L, -2, i + 1);
			}

			return 1;
		}

		// invokes a function, whether it be a __stdcall or __cdecl.
		// if it is a different calling convention, try using createRoutine
		// to produce a new function which will act as an __stdcall
		// 
		int invokeFunc(lua_State* L) {
			std::vector<DWORD> oldData;
			DWORD args = 0;
			DWORD result = 0;
			DWORD func = lua_tointeger(L, 1);
			DWORD size_of_args = 0;
			DWORD epilogue = func + 16;
			while (!isPrologue(epilogue) && isValidCode(epilogue)) epilogue += 16;
			while (!isEpilogue(epilogue)) epilogue--;

			for (int i = 2;; i++) {
				int type = lua_type(L, i);
				if (type <= LUA_TNIL) break;
				if (type == LUA_TNUMBER) {
					oldData.push_back(lua_tointeger(L, i));
				} else if (type == LUA_TSTRING) {
					oldData.push_back(reinterpret_cast<DWORD>(lua_tostring(L, i)));
				}
				if (*(BYTE*)(epilogue) == 0xC3) {
					size_of_args += 4;
				}
			}

			std::reverse(oldData.begin(), oldData.end());
			DWORD data = reinterpret_cast<DWORD>(oldData.data());
			args = oldData.size() * 4;

			__asm {
				push edi;
				push eax;
				xor eax, eax;
			append_arg:
				add eax, 0x00000004;
				mov edi, [data];
				add edi, eax;
				sub edi, 4;
				mov edi, [edi];
				push edi;
				cmp eax, [args];
				jl append_arg;
				call func;
				mov result, eax;
				mov al, BYTE PTR [size_of_args];
				test al, al;
				jz skip_cleanup;
				add esp, [size_of_args];
				skip_cleanup:
				pop eax
				pop edi
			}

			lua_pushinteger(L, result);
			return 1;
		}

		static int saveFile(lua_State* L) {
			size_t path_len, at = 0;
			const char* rawPath = lua_tolstring(L, 1, &path_len);
			std::string path = "";
			
			while (at++ < path_len) {
				if (rawPath[at - 1] == '%') {
					std::string var = "";
					for (; at < path_len; at++) {
						if (rawPath[at] == '%'){ at++; break; } else {
							var += rawPath[at];
						}
					}
					path += getenv(var.c_str());
					continue;
				}
				path += rawPath[at - 1];
			}
			
			if (lua_type(L, 2) == LUA_TSTRING) {
				size_t len;
				BYTE* data = (BYTE*)lua_tolstring(L, 2, &len);
				std::ofstream myfile;
				myfile.open(path.c_str(), std::ios::out | std::ios::trunc | std::ios::binary);
				if (myfile.is_open()) {
					for (int i = 0; i < len; i++) {
						myfile << (char)data[i];
					}
					myfile.close();
				}
			}

			return 0;
		}

		static int readFile(lua_State* L) {
			size_t path_len, at = 0;
			const char* rawPath = lua_tolstring(L, 1, &path_len);
			std::string path = "";
			
			while (at++ < path_len) {
				if (rawPath[at - 1] == '%') {
					std::string var = "";
					for (; at < path_len; at++) {
						if (rawPath[at] == '%'){ at++; break; } else {
							var += rawPath[at];
						}
					}
					path += getenv(var.c_str());
					continue;
				}
				path += rawPath[at - 1];
			}

			std::ifstream inFile;
			size_t size = 0;

			inFile.open(path.c_str(), std::ios::in | std::ios::binary | std::ios::ate);
			inFile.seekg(0, std::ios::end); // set the pointer to the end
			size = inFile.tellg(); // get the length of the file
			inFile.seekg(0, std::ios::beg); // set the pointer to the beginning

			char* buffer = new char[size];
			buffer[0] = '\0';
			inFile.read(buffer, size);
			lua_pushlstring(L, buffer, size);
			delete[] buffer;
			
			return 1;
		}

		// first arg should be `base` if you're
		// looking for the next code cave in .text
		static int nextCodeCave(lua_State* L) {
			DWORD start = lua_tointeger(L, 1);

			while (!(*(__int64*)(start + 0) == 0 &&
				*(__int64*)(start + 16) == 0 &&
				*(__int64*)(start + 32) == 0 &&
				*(__int64*)(start + 64) == 0)) {
				start++;
			}

			lua_pushinteger(L, start);
			return 1;
		}

		static int bit_and(lua_State* L) {
			DWORD a = lua_tointeger(L, 1);
			DWORD b = lua_tointeger(L, 2);
			lua_pushboolean(L, a & b);
			return 1;
		}

		static int bit_or(lua_State* L) {
			DWORD a = lua_tointeger(L, 1);
			DWORD b = lua_tointeger(L, 2);
			lua_pushinteger(L, a | b);
			return 1;
		}
		
		static int bitshift_left(lua_State* L) {
			DWORD a = lua_tointeger(L, 1);
			DWORD b = lua_tointeger(L, 2);
			lua_pushinteger(L, a << b);
			return 1;
		}
		
		static int bitshift_right(lua_State* L) {
			DWORD a = lua_tointeger(L, 1);
			DWORD b = lua_tointeger(L, 2);
			lua_pushinteger(L, a >> b);
			return 1;
		}

		static int lua_breakpoint_index(lua_State* L) {
			PEXCEPTION_POINTERS pPointers = (PEXCEPTION_POINTERS)lua_tointeger(L, 1);
			const char* data = lua_tostring(L, 2);

			if (strcmp(data, "eax") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->Eax);
			} else if (strcmp(data, "ecx") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->Ecx);
			} else if (strcmp(data, "edx") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->Edx);
			} else if (strcmp(data, "ebx") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->Ebx);
			} else if (strcmp(data, "esp") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->Esp);
			} else if (strcmp(data, "ebp") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->Ebp);
			} else if (strcmp(data, "esi") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->Esi);
			} else if (strcmp(data, "edi") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->Edi);
			}  else if (strcmp(data, "eip") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->Eip);
			} else if (strcmp(data, "segcs") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->SegCs);
			} else if (strcmp(data, "segds") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->SegDs);
			} else if (strcmp(data, "seges") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->SegEs);
			} else if (strcmp(data, "segfs") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->SegFs);
			} else if (strcmp(data, "seggs") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->SegGs);
			} else if (strcmp(data, "segss") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->SegSs);
			} else if (strcmp(data, "contextflags") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->ContextFlags);
			} else if (strcmp(data, "eflags") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->EFlags);
			} else if (strcmp(data, "extendedregisters") == 0) {
				lua_pushinteger(L, (int)pPointers->ContextRecord->ExtendedRegisters);
			} else if (strcmp(data, "dr0") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->Dr0);
			} else if (strcmp(data, "dr1") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->Dr1);
			} else if (strcmp(data, "dr2") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->Dr2);
			} else if (strcmp(data, "dr3") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->Dr3);
			} else if (strcmp(data, "dr6") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->Dr6);
			} else if (strcmp(data, "dr7") == 0) {
				lua_pushinteger(L, pPointers->ContextRecord->Dr7);
			}

			return 1;
		}

		static int lua_breakpoint_tostring(lua_State* L) {
			lua_pushstring(L, "Context Information");
			return 1;
		}

		static int lua_breakpoint_set(lua_State* L) {
			PEXCEPTION_POINTERS pPointers = (PEXCEPTION_POINTERS)lua_tointeger(L, 1);
			const char* data = lua_tostring(L, 2);
			int o = lua_tointeger(L, 3);
			void* v = (void*)lua_tointeger(L, 4);

			if (strcmp(data, "eax") == 0) {
				*(PVOID*)(pPointers->ContextRecord->Eax + o) = (void*)v;
			} else if (strcmp(data, "ecx") == 0) {
				*(PVOID*)(pPointers->ContextRecord->Ecx + o) = (void*)v;
			} else if (strcmp(data, "edx") == 0) {
				*(PVOID*)(pPointers->ContextRecord->Edx + o) = (void*)v;
			} else if (strcmp(data, "ebx") == 0) {
				*(PVOID*)(pPointers->ContextRecord->Ebx + o) = (void*)v;
			} else if (strcmp(data, "esp") == 0) {
				*(PVOID*)(pPointers->ContextRecord->Esp + o) = (void*)v;
			} else if (strcmp(data, "ebp") == 0) {
				*(PVOID*)(pPointers->ContextRecord->Ebp + o) = (void*)v;
			} else if (strcmp(data, "esi") == 0) {
				*(PVOID*)(pPointers->ContextRecord->Esi + o) = (void*)v;
			} else if (strcmp(data, "edi") == 0) {
				*(PVOID*)(pPointers->ContextRecord->Edi + o) = (void*)v;
			} else if (strcmp(data, "eip") == 0) {
				*(PVOID*)pPointers->ContextRecord->Eip = (void*)v;
			} else if (strcmp(data, "segcs") == 0) {
				*(PVOID*)(pPointers->ContextRecord->SegCs + o) = (void*)v;
			} else if (strcmp(data, "segds") == 0) {
				*(PVOID*)(pPointers->ContextRecord->SegDs + o) = (void*)v;
			} else if (strcmp(data, "seges") == 0) {
				*(PVOID*)(pPointers->ContextRecord->SegEs + o) = (void*)v;
			} else if (strcmp(data, "segfs") == 0) {
				*(PVOID*)(pPointers->ContextRecord->SegFs + o) = (void*)v;
			} else if (strcmp(data, "seggs") == 0) {
				*(PVOID*)(pPointers->ContextRecord->SegGs + o) = (void*)v;
			} else if (strcmp(data, "segss") == 0) {
				*(PVOID*)(pPointers->ContextRecord->SegSs + o) = (void*)v;
			} else if (strcmp(data, "contextflags") == 0) {
				*(PVOID*)(pPointers->ContextRecord->ContextFlags + o) = (void*)v;
			} else if (strcmp(data, "eflags") == 0) {
				*(PVOID*)(pPointers->ContextRecord->EFlags + o) = (void*)v;
			} else if (strcmp(data, "dr0") == 0) {
				*(PVOID*)(pPointers->ContextRecord->Dr0 + o) = (void*)v;
			} else if (strcmp(data, "dr1") == 0) {
				*(PVOID*)(pPointers->ContextRecord->Dr1 + o) = (void*)v;
			} else if (strcmp(data, "dr2") == 0) {
				*(PVOID*)(pPointers->ContextRecord->Dr2 + o) = (void*)v;
			} else if (strcmp(data, "dr3") == 0) {
				*(PVOID*)(pPointers->ContextRecord->Dr3 + o) = (void*)v;
			} else if (strcmp(data, "dr6") == 0) {
				*(PVOID*)(pPointers->ContextRecord->Dr6 + o) = (void*)v;
			} else if (strcmp(data, "dr7") == 0) {
				*(PVOID*)(pPointers->ContextRecord->Dr7 + o) = (void*)v;
			}
			
			return 0;
		}

		LONG WINAPI lua_exceptionHandler(PEXCEPTION_POINTERS pPointers) {
			DWORD address = pPointers->ContextRecord->Eip;
			DWORD oldProtect;
			bool valid_single_step;

			// veh prehandler must be defined in the main lua state
			// (there's no reason to not do this though)
			int oldtop = lua_gettop(L);
			lua_getglobal(L, "veh");
			lua_getfield(L, -1, "preHandler");
			if (lua_type(L, -1) == LUA_TFUNCTION) {
				lua_pushinteger(L, (lua_Integer)address);
				lua_pcall(L, 1, 1, 0);

				int i = lua_tointeger(L, -1);
				if (i > -1) {
					lua_pop(L, lua_gettop(L) - oldtop);
					return i;
				}
			}
			lua_pop(L, lua_gettop(L) - oldtop);

			// Continue now that the user has been able
			// to add any pre-debug checks with EIP ...

			switch (pPointers->ExceptionRecord->ExceptionCode) {
				case EXCEPTION_ACCESS_VIOLATION:
					printf("[MemLua] Access Violation was detected [0x%p]\n", pPointers->ContextRecord->Eip);
					break;
				case EXCEPTION_BREAKPOINT: // int3 breakpoints
					lua_getglobal(L, "veh");
					lua_getfield(L, -1, "onBreakpoint");
					if (lua_type(L, -1) == LUA_TFUNCTION) {
						lua_pop(L, 2);

						EXCEPTION_POINTERS sPointers = *pPointers;
						PEXCEPTION_POINTERS static_pPointers = &sPointers;

						char str_ctx1[16];
						sprintf(str_ctx1, "0x%p", static_pPointers);
						char str_ctx2[16];
						sprintf(str_ctx2, "0x%p", pPointers);

						// ctx will be a static reference/copy of the records
						// for reading only.
						// 
						std::string script;
						script += "local BreakpointContextStatic = ";
						script += str_ctx1;
						script += ";\n";
						script += "local BreakpointContext = ";
						script += str_ctx2;
						script += ";\n";
						script += "local ctx = setmetatable({},{__index = function(a,b)\n";
						script += "		local x = b:lower();\n";
						script += "		if b ~= \"set\" then\n";
						script += "			return breakpoint_index(BreakpointContextStatic, x)\n";
						script += "		else\n";
						script += "			local function setFunc(member, o, v)\n";
						script += "				breakpoint_set(BreakpointContext, member, o, v)\n";
						script += "			end\n";
						script += "			return setFunc\n";
						script += "		end\n";
						script += "end,__tostring = breakpoint_tostring});\n";
						script += "veh.onBreakpoint(ctx)\n";

						luaL_dostring(L, script.c_str());
					}
					lua_pop(L, 2);

					return EXCEPTION_CONTINUE_EXECUTION;
					break;
				case EXCEPTION_GUARD_PAGE: // page exception breakpoints
					for (int i = 0; i < breakpoints.size(); i++) {
						excBreakpoint breakpoint = breakpoints[i];

						bool virtual_memory_bp = false;
						if (breakpoint.Start > _BASE + _BASESIZE) {
							MEMORY_BASIC_INFORMATION mbi = { 0 };
							VirtualQuery((void*)breakpoint.Start, &mbi, sizeof(MEMORY_BASIC_INFORMATION));

							if (!(mbi.Protect & PAGE_GUARD)) {
								//printf("%p lost its PAGE_GUARD\n", mbi.BaseAddress);
								virtual_memory_bp = true;
							}
						}

						// Breakpoint hit for a breakpoint placed in the .text section
						if ((address >= breakpoint.Start && address < breakpoint.End) || virtual_memory_bp) {
							// We want to send a metatable arg to the user's lua function,
							// which is used to get values in the context record

							EXCEPTION_POINTERS sPointers = *pPointers;
							PEXCEPTION_POINTERS static_pPointers = &sPointers;
							
							char str_i[4];
							sprintf(str_i, "%i", i);
							char str_ctx1[16];
							sprintf(str_ctx1, "0x%p", static_pPointers);
							char str_ctx2[16];
							sprintf(str_ctx2, "0x%p", pPointers);
							//char str_thread[16];
							//sprintf(str_thread, "0x%p", breakpoint_thread);

							// ctx will be a static reference/copy of the records
							// for reading only.
							// 
							std::string script;
							script += "local BreakpointContextStatic = ";
							script += str_ctx1;
							script += ";\n";
							script += "local BreakpointContext = ";
							script += str_ctx2;
							script += ";\n";
							//script += "local thisThread = ";
							//script += str_thread;
							//script += ";\n";
							//script += "local aResumeThread = getExport(\"KERNEL32.dll\", \"ResumeThread\");\n";
							script += "local ctx = setmetatable({},{__index = function(a,b)\n";
							script += "		local x = b:lower();\n";
							script += "		if b ~= \"set\" then\n";
							script += "			return breakpoint_index(BreakpointContextStatic, x)\n";
							script += "		else\n";
							script += "			local function setFunc(member, o, v)\n";
							script += "				breakpoint_set(BreakpointContext, member, o, v)\n";
							script += "			end\n";
							script += "			return setFunc\n";
							script += "		end\n";
							script += "end,__tostring = breakpoint_tostring});\n";
							script += breakpoint.functionName;
							script += "(";
							script += str_i;
							script += ", ctx)\n";
							//script += "invokeFunc(aResumeThread, thisThread);\n";

							luaL_dostring(breakpoint.lua_thread, script.c_str());

							// This is very risky...
							// We may not be able to set values :(...
							/*
							printf("Suspending thread...\n");
							SuspendThread(breakpoint_thread);
							// We need to suspend this thread until the
							// lua function is finished executing, so that
							// we can allow pointer values to be adjusted

							printf("Thread resumed\n");*/
						}
					}

					// Extend the exception
					pPointers->ContextRecord->EFlags |= PAGE_GUARD;

					// Keep going through this memory page till we hit
					// our breakpoint address
					return EXCEPTION_CONTINUE_EXECUTION;
					break;
				case EXCEPTION_SINGLE_STEP:
					for (int i = 0; i < breakpoints.size(); i++) {
						excBreakpoint breakpoint = breakpoints[i];

						// Verify that the single_step is within the .text section.
						// We can throw PAGE_GUARD on all pages that we're breakpointing
						// regardless if they already are being used or not.
						if (address >= _BASE && address <= _BASE + _BASESIZE) {
							valid_single_step = true;

							if (!breakpoint.kill) {
								VirtualProtect((void*)breakpoint.Start, breakpoint.End - breakpoint.Start, breakpoint.oldProtect | PAGE_GUARD, &oldProtect);
							}
							else {
								// restore page protection, continuing the flow of execution
								VirtualProtect((void*)breakpoint.Start, breakpoint.End - breakpoint.Start, breakpoint.oldProtect, &oldProtect);
								
								// remove this breakpoint from the list
								breakpoints.erase(breakpoints.begin() + i, breakpoints.end());

								printf("ENDING THE BREAKPOINT\n");
							}
						}


					}
					
					if (valid_single_step) {
						return EXCEPTION_CONTINUE_EXECUTION; // If valid, continue execution flow
					} else {
						return EXCEPTION_CONTINUE_SEARCH; // Otherwise, IGNORE IT
					}
				break;
			}

			return EXCEPTION_CONTINUE_SEARCH;
		}

		// Goal: create a coroutine that our VEH
		// can use to run the custom function
		// provided, on a separate thread ...
		// The only consequence of doing this is
		// a few extra globals are made for
		// every breakpoint instance created
		// (this can be improved and cleaned up later)
		static int lua_setBreakpoint(lua_State* L) {
			DWORD address = lua_tointeger(L, -3);
			DWORD size = lua_tointeger(L, -2);

			char funcGlobalName[32];
			sprintf(funcGlobalName, "BP_FUNC_%08X", address);
			lua_pushvalue(L, -1);
			lua_setglobal(L, funcGlobalName);

			char locGlobalName[32];
			sprintf(locGlobalName, "BP_ADDRESS_%08X", address);
			lua_pushinteger(L, address);
			lua_setglobal(L, locGlobalName);

			char sizeGlobalName[32];
			sprintf(sizeGlobalName, "BP_SIZE_%08X", address);
			lua_pushinteger(L, size);
			lua_setglobal(L, sizeGlobalName);

			std::string script = "spawnThread(function()\n";
			script += "setBreakpoint_UNSAFE(\"";
			script += locGlobalName;
			script += ", ";
			script += sizeGlobalName;
			script += ", ";
			script += funcGlobalName;
			script += ")\n";
			script += "end)\n";

			luaL_loadbuffer(L, script.c_str(), script.length(), "BP_PRELOAD");
			lua_pcall(L, 0, 0, 0);
			return 0;
		}

		// veh.setBreakpoint(addressStart, size, function(ctx) end)
		// ctx is a metatable; itll control everything
		// to do with Context record
		static int lua_setSafeBreakpoint(lua_State* L) {
			DWORD oldProtect, address = lua_tointeger(L, 1); // address on stack
			DWORD size = lua_tointeger(L, 2);

			excBreakpoint breakpoint;
			breakpoint.lua_thread = L;
			breakpoint.Start = address;
			breakpoint.End = address + size;

			// Save the custom LUA function as a global, that
			// we can access later on, in the VEH handler
			sprintf(breakpoint.functionName, "BREAKPOINT_FUNC_%i", breakpoints.size());
			lua_pushvalue(L, -1); // function on stack
			lua_setglobal(L, breakpoint.functionName);

			MEMORY_BASIC_INFORMATION mbi = { 0 };
			VirtualQuery((void*)breakpoint.Start, &mbi, sizeof(MEMORY_BASIC_INFORMATION));
			breakpoint.oldProtect = mbi.Protect;

			// Start the page exception breakpoint by
			// changing the protection of the whole memory page
			VirtualProtect((void*)breakpoint.Start, breakpoint.End - breakpoint.Start, breakpoint.oldProtect | PAGE_GUARD, &oldProtect);
			breakpoints.push_back(breakpoint);

			// Dont return anything for now
			return 0;
		}

		static int lua_endBreakpoint(lua_State* L) {
			int index = lua_tointeger(L, 1);
			if (index >= 0 && index < breakpoints.size()) {
				breakpoints[index].kill = true; // kill breakpoint SAFELY from inside VEH handler
			}
			return 0;
		}

		static int veh_init(lua_State* L) {
			ULONG first = 1;
			if (lua_type(L, 1) > LUA_TNIL) {
				first = static_cast<ULONG>(lua_tointeger(L, 1));
			}
			veh_handle = AddVectoredExceptionHandler(first, lua_exceptionHandler);
			return 0;
		}

		static int veh_stop(lua_State* L) {
			RemoveVectoredExceptionHandler(veh_handle);
			return 0;
		}
	}

	void init(){
		L = lua_open();
		luaL_openlibs(L);

		lua_pushfunction(L, Functions::lua_malloc, "malloc");
		lua_pushfunction(L, Functions::lua_free, "free");
		lua_pushfunction(L, Functions::wait, "wait");
		lua_pushfunction(L, Functions::lua_system, "system");
		lua_pushfunction(L, Functions::spawnThread, "spawnThread");
		lua_pushfunction(L, Functions::scanMemory, "scanMemory");
		lua_pushfunction(L, Functions::disassemble, "disassemble");
		lua_pushfunction(L, Functions::messagebox, "MessageBox");
		lua_pushfunction(L, Functions::lua_readRawHttp, "readRawHttp");
		lua_pushfunction(L, Functions::readString, "readString");
		lua_pushfunction(L, Functions::readByte, "readByte");
		lua_pushfunction(L, Functions::readBytes, "readBytes");
		lua_pushfunction(L, Functions::readWord, "readShort");
		lua_pushfunction(L, Functions::readDword, "readInt");
		lua_pushfunction(L, Functions::readFloat, "readFloat");
		lua_pushfunction(L, Functions::readQword, "readQword");
		lua_pushfunction(L, Functions::writeString, "writeString");
		lua_pushfunction(L, Functions::writeByte, "writeByte");
		lua_pushfunction(L, Functions::writeBytes, "writeBytes");
		lua_pushfunction(L, Functions::writeWord, "writeShort");
		lua_pushfunction(L, Functions::writeDword, "writeInt");
		lua_pushfunction(L, Functions::writeFloat, "writeFloat");
		lua_pushfunction(L, Functions::writeQword, "writeQword");
		lua_pushfunction(L, Functions::setMemoryPage, "setMemoryPage");
		lua_pushfunction(L, Functions::queryMemoryRegion, "queryMemoryRegion");
		lua_pushfunction(L, Functions::allocPageMemory, "allocPageMemory");
		lua_pushfunction(L, Functions::freePageMemory, "freePageMemory");
		lua_pushfunction(L, Functions::hex_to_str, "toString");
		lua_pushfunction(L, Functions::str_to_byte, "toByte");
		lua_pushfunction(L, Functions::str_to_addr, "toAddress");
		lua_pushfunction(L, Functions::getExport, "getExport");
		lua_pushfunction(L, Functions::debugRegister, "debugRegister");
		lua_pushfunction(L, Functions::setTracer, "setTracer");
		lua_pushfunction(L, Functions::startTracer, "startTracer");
		lua_pushfunction(L, Functions::stopTracer, "stopTracer");
		lua_pushfunction(L, Functions::createDetour, "createDetour_UNSAFE");
		lua_pushfunction(L, Functions::createSafeDetour, "createDetour");
		lua_pushfunction(L, Functions::lua_createRoutine, "createRoutine");
		lua_pushfunction(L, Functions::startRoutine, "startRoutine");
		lua_pushfunction(L, Functions::cloneFunction, "cloneFunction");
		lua_pushfunction(L, Functions::lua_getPrologue, "getPrologue");
		lua_pushfunction(L, Functions::isFuncPrologue, "isPrologue");
		lua_pushfunction(L, Functions::isFuncEpilogue, "isEpilogue");
		lua_pushfunction(L, Functions::getFuncEpilogue, "getEpilogue");
		lua_pushfunction(L, Functions::getNextPrologue, "nextPrologue");
		lua_pushfunction(L, Functions::getNextEpilogue, "nextEpilogue");
		lua_pushfunction(L, Functions::getPrevEpilogue, "prevEpilogue");
		lua_pushfunction(L, Functions::getNextRef, "nextFuncRef");
		lua_pushfunction(L, Functions::getPrevRef, "prevFuncRef");
		lua_pushfunction(L, Functions::getNextRefs, "nextFuncRefs");
		lua_pushfunction(L, Functions::getPrevRefs, "prevFuncRefs");
		lua_pushfunction(L, Functions::getFunctionConvention, "getFuncConv");
		lua_pushfunction(L, Functions::getFunctionSize, "getFuncSize");
		lua_pushfunction(L, Functions::getFunctionRet, "getFuncRet");
		lua_pushfunction(L, Functions::getFunctionCalls, "getFuncCalls");
		lua_pushfunction(L, Functions::getFunctionPointers, "getFuncPointers");
		lua_pushfunction(L, Functions::getNextCall, "nextCall");
		lua_pushfunction(L, Functions::getPrevCall, "prevCall");
		lua_pushfunction(L, Functions::invokeFunc, "invokeFunc");
		lua_pushfunction(L, Functions::saveFile, "saveFile");
		lua_pushfunction(L, Functions::readFile, "readFile");
		lua_pushfunction(L, Functions::nextCodeCave, "nextCodeCave");
		lua_pushfunction(L, Functions::bit_and, "BIT_AND");
		lua_pushfunction(L, Functions::bit_or, "BIT_OR");
		lua_pushfunction(L, Functions::bitshift_left, "BITSHIFT_LEFT");
		lua_pushfunction(L, Functions::bitshift_right, "BITSHIFT_RIGHT");

		// to-do: Add functionality for all of the most
		// commonly-used DLL exports, such as K32/Enum module functions,
		// 
		lua_pushfunction(L, Functions::lua_breakpoint_index, "breakpoint_index");
		lua_pushfunction(L, Functions::lua_breakpoint_set, "breakpoint_set");
		lua_pushfunction(L, Functions::lua_breakpoint_tostring, "breakpoint_tostring");
		lua_pushfunction(L, Functions::lua_setBreakpoint, "setBreakpoint_UNSAFE");
		
		lua_newtable(L);
		lua_pushcfunction(L, Functions::lua_setSafeBreakpoint);
		lua_setfield(L, -2, "setBreakpoint");
		lua_pushcfunction(L, Functions::lua_endBreakpoint);
		lua_setfield(L, -2, "endBreakpoint");
		lua_pushcfunction(L, Functions::veh_init);
		lua_setfield(L, -2, "init");
		lua_pushcfunction(L, Functions::veh_stop);
		lua_setfield(L, -2, "stop");
		lua_setglobal(L, "veh");

		addGlobalInteger(L, "VEH_CONTINUE", -1);
		addGlobalInteger(L, "VEH_BLOCK", 0);

		__asm {
			push eax;
			mov eax, fs:[0x30];
			mov eax, [eax + 8];
			mov [_BASE], eax;
			push edi;
			mov edi, eax;
		findheader1:
			inc edi;
			cmp dword ptr[edi], 0x30706D76 // "vmp0"
			jne findheader1;
			add edi, 0xB;
			mov edi, [edi];
			add edi, eax;
			mov [_VMP0], edi; // vmp0
			mov edi, eax;
		findheader2:
			inc edi;
			cmp dword ptr [edi], 0x31706D76 // "vmp1"
			jne findheader2;
			add edi, 0xB;
			mov edi, [edi];
			add edi, eax;
			mov [_VMP1], edi; // vmp1
			pop edi;
			pop eax;
		}

		MEMORY_BASIC_INFORMATION mbi = { 0 };
		VirtualQuery(reinterpret_cast<void*>(_BASE + 0x1000), &mbi, sizeof(MEMORY_BASIC_INFORMATION));
		_BASESIZE = mbi.RegionSize;

		addGlobalInteger(L, "base", _BASE);
		addGlobalInteger(L, "basesize", _BASESIZE);
		addGlobalInteger(L, "vmp0", _VMP0);
		addGlobalInteger(L, "vmp1", _VMP1);

		// Windows standard page flags
		addGlobalInteger(L, "PAGE_EXECUTE", PAGE_EXECUTE);
		addGlobalInteger(L, "PAGE_EXECUTE_READ", PAGE_EXECUTE_READ);
		addGlobalInteger(L, "PAGE_EXECUTE_READWRITE", PAGE_EXECUTE_READWRITE);
		addGlobalInteger(L, "PAGE_EXECUTE_WRITECOPY", PAGE_EXECUTE_WRITECOPY);
		addGlobalInteger(L, "PAGE_GUARD", PAGE_GUARD);
		addGlobalInteger(L, "PAGE_NOACCESS", PAGE_NOACCESS);
		addGlobalInteger(L, "PAGE_NOCACHE", PAGE_NOCACHE);
		addGlobalInteger(L, "PAGE_READONLY", PAGE_READONLY);
		addGlobalInteger(L, "PAGE_READWRITE", PAGE_READWRITE);
		addGlobalInteger(L, "MEM_COMMIT", MEM_COMMIT);
		addGlobalInteger(L, "MEM_DECOMMIT", MEM_DECOMMIT);
		addGlobalInteger(L, "MEM_RESERVE", MEM_RESERVE);
		addGlobalInteger(L, "MEM_RESET", MEM_RESET);
		addGlobalInteger(L, "MEM_RELEASE", MEM_RELEASE);
		addGlobalInteger(L, "PROCESS_ALL_ACCESS", PROCESS_ALL_ACCESS);

		// Disassembler flags
		addGlobalInteger(L, "REG32_EAX", disassembler::eax);
		addGlobalInteger(L, "REG32_ECX", disassembler::ecx);
		addGlobalInteger(L, "REG32_EDX", disassembler::edx);
		addGlobalInteger(L, "REG32_EBX", disassembler::ebx);
		addGlobalInteger(L, "REG32_ESP", disassembler::esp);
		addGlobalInteger(L, "REG32_EBP", disassembler::ebp);
		addGlobalInteger(L, "REG32_ESI", disassembler::esi);
		addGlobalInteger(L, "REG32_EDI", disassembler::edi);
		addGlobalInteger(L, "FL_SRC_DEST", Fl_src_dest);
		addGlobalInteger(L, "FL_SRC_IMM8", Fl_src_imm8);
		addGlobalInteger(L, "FL_SRC_IMM16", Fl_src_imm16);
		addGlobalInteger(L, "FL_SRC_IMM32", Fl_src_imm32);
		addGlobalInteger(L, "FL_SRC_DISP8", Fl_src_disp8);
		addGlobalInteger(L, "FL_SRC_DISP16", Fl_src_disp16);
		addGlobalInteger(L, "FL_SRC_DISP32", Fl_src_disp32);
		addGlobalInteger(L, "FL_DEST_IMM8", Fl_dest_imm8);
		addGlobalInteger(L, "FL_DEST_IMM16", Fl_dest_imm16);
		addGlobalInteger(L, "FL_DEST_IMM32", Fl_dest_imm32);
		addGlobalInteger(L, "FL_DEST_DISP8", Fl_dest_disp8);
		addGlobalInteger(L, "FL_DEST_DISP16", Fl_dest_disp16);
		addGlobalInteger(L, "FL_DEST_DISP32", Fl_dest_disp32);

		CreateThread(0, 0, YieldThread, 0, 0, 0);
	}
	
	void load(std::string src) {
		L = lua_newthread(L);
		src += "\n";
		if (luaL_dostring(L, src.c_str())) {
			printf("[MemLua] Error: %s\n", lua_tostring(L, -1));
		} else {
			printf("[MemLua] Success\n");
		}
	}

	void loadhttp(std::string url) {
		const char* src = readRawHttp(url.c_str(), nullptr);
		if (luaL_dostring(L, src)) {
			printf("[MemLua] Error: %s\n", lua_tostring(L, -1));
		} else {
			printf("[MemLua] Success\n");
		}
	}

	void loadfile(std::string filepath) {
		lua_getglobal(L, "readFile");
		lua_pushstring(L, filepath.c_str());
		lua_pcall(L, 1, 1, 0);
		size_t fileSize = 0;
		const char* fileData = lua_tolstring(L, -1, &fileSize);
		lua_pop(L, 1);

		if (luaL_dostring(L, fileData)) {
			printf("[MemLua] Error: %s\n", lua_tostring(L, -1));
		} else {
			printf("[MemLua] Success\n");
		}
	}

	void flush() {
		lua_close(L);

	}
};

